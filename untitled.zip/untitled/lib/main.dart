import 'package:flutter/material.dart';

void main() {
  runApp(MyApp()); //we use this to run the app
}
//now we make stateless widget
/* when widget does something or suppose if we interact with it and it changes values
then it is statefull widget and if it doesnt then it is stateless widget
*/

//stless= stateless widget
//hover your cursor to class to transform a stateless widget into statefull and also make widgets
//if we press ctr+b over a widget we can know what is inside that widget
//ctrl+d to make same widget again
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea( //taking the scaffold in safearea to fit every phone screen
        child: Scaffold(
          appBar: AppBar(
            title: Text('The 1975'),
            centerTitle: true,
            leading:Icon(Icons.message) , //to add icons in the left we dont need to use action

            actions: [    //here we are taking an action to do something
              IconButton(onPressed: (){    //adding a IconButton here

              }, icon: Icon(Icons.add_a_photo))
            ],
          ), //we have to include appbar before body
          //centertitle for centering
//when we want to use multiple widget we have to use children
          body:
             ListView(  //list view for list ui type and no overflow
               children: [
                 Column(
                   children: [
                     Container(
                       height: 200,
                       width: 300,
                       decoration: BoxDecoration(color: Colors.purpleAccent),
                       child: Text("I Like It When You Sleep, for You Are So Beautiful Yet So Unaware of It",style: TextStyle(fontSize: 30,color: Colors.black),),

                     ),
                     SizedBox(height: 10,), //we used sized box to separate the containers
                     Container(
                       height: 200,
                       width: 300,
                       decoration: BoxDecoration(color: Colors.pinkAccent),
                       child: Text("A Brief Inquiry into Online Relationships",style: TextStyle(fontSize: 30,color: Colors.white),),
                     ),
                     SizedBox(height: 10,),
                     Container(
                       height: 200,
                       width: 300,
                       decoration: BoxDecoration(color: Colors.yellowAccent),
                       child: Text("Notes on a Conditional Form",style: TextStyle(fontSize: 30,color: Colors.lightBlueAccent),),
                     ),
                     SizedBox(height: 10,),
                     Container(
                       height: 200,
                       width: 300,
                       decoration: BoxDecoration(color: Colors.black12),
                       child: Text("Being Funny in a Foreign Language",style: TextStyle(fontSize: 30,color: Colors.blueGrey),),
                     ),
                     ElevatedButton(onPressed: (){

                     }, child: Text('Ami Button'))

                   ],
                 ),
               ]
             ),
          )





          ),
        );

  }
}
